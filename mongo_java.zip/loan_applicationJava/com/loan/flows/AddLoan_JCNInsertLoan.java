package com.loan.flows;

import org.bson.Document;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.rmi.util.list.LinkedList.Item;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

public class AddLoan_JCNInsertLoan extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		MbMessage newMessage = null;
		try {
			newMessage = new MbMessage();
			MbMessage outMessage = new MbMessage(inMessage);
			MbMessage outLocalEnv = new MbMessage(inAssembly.getLocalEnvironment());
			MbMessage outExceptionList = new MbMessage(inAssembly.getExceptionList());
			outAssembly = new MbMessageAssembly(inAssembly, outLocalEnv, outExceptionList, newMessage);
				
			DbConnection conn = new DbConnection();
			MongoCollection<Document> table = conn.getCollection(CollectionEnum.LOAN);
			
			String loan_number = outMessage.getRootElement().getFirstElementByPath("XMLNSC/root/loan/loan_number").getValueAsString();
			MbElement item = outMessage.getRootElement().getFirstElementByPath("XMLNSC/root/loan").getFirstChild();
			
			outMessage.clearMessage();
			
			MbElement xml = newMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement root =  xml.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "root", null);
			
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("loan_number", loan_number);
			
			FindIterable<Document> doc = table.find(searchQuery);
			MongoCursor<Document> iterator = doc.iterator();
			
			if(iterator.hasNext()){
				root.createElementAsLastChild(MbXMLNSC.FIELD, "status", "true");
				root.createElementAsLastChild(MbXMLNSC.FIELD, "message", "Provided loan number, "+loan_number +" already exists");
				root.createElementAsLastChild(MbXMLNSC.FIELD, "error_code","2002");
					
			}else{
				Document document = new Document();				
				while(true){
					document.put(item.getName().toString(), item.getValue().toString());
					if(item.getNextSibling() == null){
						break;
					}
					item = item.getNextSibling();
				}
				table.insertOne(document);
				
				root.createElementAsLastChild(MbXMLNSC.FIELD, "status", "false");
				root.createElementAsLastChild(MbXMLNSC.FIELD, "message", "Loand Added Successfully.");
				root.createElementAsLastChild(MbXMLNSC.FIELD, "error_code","");
			}
			
			newMessage.finalizeMessage(MbMessage.FINALIZE_VALIDATE);
			conn.closeConnection();
			
		} catch (MbException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		out.propagate(outAssembly);

	}

}
