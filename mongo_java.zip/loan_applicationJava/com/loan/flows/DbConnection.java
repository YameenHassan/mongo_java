package com.loan.flows;


import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class DbConnection {

	MongoClientURI uri = null;
	MongoClient mongo = null;
	MongoCollection<Document> table = null;
	MongoDatabase db = null;
	
	public MongoCollection<Document> getCollection(CollectionEnum collection){
		
		try{
			uri = new MongoClientURI("mongodb://admin:admin@127.0.0.1:27017/?authSource=admin");
			mongo = new MongoClient(uri);
			CollectionEnum cEnum = collection;
			switch(cEnum){
			case LOAN:
				db = mongo.getDatabase(collection.getValue());
				table = db.getCollection(CollectionEnum.LOANS.getValue());
				break;
			case USER:
				db = mongo.getDatabase(collection.getValue());
				table = db.getCollection(CollectionEnum.USERS.getValue());
				break;
			default:
				break;
			}
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return table;
	}
	
	public void closeConnection(){
		mongo.close();
	}
}

