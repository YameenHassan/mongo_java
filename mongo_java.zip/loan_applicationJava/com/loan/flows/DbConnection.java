package com.loan.flows;


import org.bson.Document;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class DbConnection {

	MongoClientURI uri = null;
	MongoClient mongo = null;
	MongoCollection<Document> table = null;
	MongoDatabase db = null;
	
	public MongoCollection<Document> getCollection(CollectionEnum collection){
		
		try{
			uri = new MongoClientURI(
				    "mongodb+srv://admin:admin@cluster0-t1omu.mongodb.net/test?retryWrites=true&w=majority");
			mongo = new MongoClient(uri);
			CollectionEnum cEnum = collection;
			switch(cEnum){
			case LOAN:
				db = mongo.getDatabase(collection.getValue());
				table = db.getCollection(CollectionEnum.LOANS.getValue());
				break;
			case USER:
				db = mongo.getDatabase(collection.getValue());
				table = db.getCollection(CollectionEnum.USERS.getValue());
				break;
			default:
				break;
			}
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return table;
	}
	
	public void closeConnection(){
		mongo.close();
	}
}

