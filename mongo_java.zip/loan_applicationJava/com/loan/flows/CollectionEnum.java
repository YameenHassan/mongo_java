package com.loan.flows;

public enum CollectionEnum {
	LOAN("loan"), LOANS("loans"), USERS("users"), USER("user");
	
	private String value;
	
	CollectionEnum(String value){
		this.value = value;
	}
	
	public String getValue (){
		return this.value;
	}
}
